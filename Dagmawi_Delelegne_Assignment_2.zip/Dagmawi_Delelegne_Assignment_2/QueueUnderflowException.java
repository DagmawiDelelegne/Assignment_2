
/**
 * 
 * @author Dagmawi Delelene
 *
 */
public class QueueUnderflowException extends Exception{
	/**
	 * constructor of QueueUnderflowException.
	 */
	public QueueUnderflowException() {
		this("The Queue is empty!");
	}
	/**
	 *
	 * Default constructor of StackOverflowException.
	 * @param custom
	 */
	public QueueUnderflowException(String custom) {
		super(custom);
	}
}
