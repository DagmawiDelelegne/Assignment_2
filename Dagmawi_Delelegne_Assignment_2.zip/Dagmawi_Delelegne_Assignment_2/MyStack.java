

import java.util.ArrayList;
/**
 * 
 * @author Dagmawi Delelegne
 *
 * @param <T>
 */
public class MyStack <T> implements StackInterface<T> {
	
	
	public int count, size = 0;
	public ArrayList <T> stack;
	/**
	 * empty constructor initializes the size and stack arraylist is also initialized 
	 * with size "size".
	 */
	public MyStack() {
		this.size = 100;
		stack = new ArrayList<T>(size);
	}
	/**
	 * a constructor that takes an int size and initializes both variable size and stack array
	 * list.
	 * @param size
	 */
	public MyStack(int size) {
		this.size = size;
		stack = new ArrayList<T>(size);
	}
	
	/**
	 * returns true or false based on the fact that the arrayList is empty or not.
	 * @return boolean.
	 */
	@Override
	public boolean isEmpty() {
		if (count == 0) {
			return true;
		}
		else return false;
		
	}
	/**
	 * returns true or false based on the fact that the arrayList is full or not.
	 * @return boolean.
	 */
	@Override
	public boolean isFull() {
		
		if(count == size)
		return true;
		
		else return false;
	}
	/**
	 * returns and removes an element at the top of the stack.
	 * @return T
	 */
	@Override
	public T pop() throws StackUnderflowException {
		
		if(count == 0) {
			throw new StackUnderflowException();
		}
		
		else {
		count--;
		T holder = stack.get(count);
		stack.remove(count);
		return holder;
		}
		
	}
/**
 * returns the item at the top of the stack.
 * @return item at the top of the stack.
 */
	@Override
	public T top() throws StackUnderflowException {
		if(count == 0) {
			throw new StackUnderflowException();
		}
		else {
		return stack.get(count - 1);
		}
	}

	/**
	 * returns the amount of items in the stack.
	 * @return count
	 */
	@Override
	public int size() {
		return count;
	}

	@Override
	public boolean push(T e) throws StackOverflowException {
		
		if(count == size) {
			throw new StackOverflowException();
		}
		else {
			stack.add(e);
			count++;
			return true;
		}
	}
/**
 * gives a string form of what's in the stack.
 * @return holder
 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		for(int i = 0 ; i < count; i++) {
			s.append(stack.get(i));
		}
		String holder = s.toString();
		
		return holder;
	}
	
	/**
	 * gives a string form of what's in the stack with the delimiter in between each element.
	 * @param delimiter
	 * @return holder
	 */
	@Override
	public String toString(String delimiter) {
		
		StringBuilder s = new StringBuilder();
		for(int i = 0 ; i < count ; i++) {
			s.append(stack.get(i)).append(delimiter);
		}
		int l = s.length()-1;
		
		String holder = s.deleteCharAt(l).toString();
		
		return holder;
	}
	/**
	 * makes a copy of an array list and then adds all the elements to stack arrayList.
	 * @param ArrayList<T> list
	 * 
	 */
	public void fill(ArrayList<T> list){
		try {
		ArrayList<T> copy = new ArrayList<T>(list);
	        stack.addAll(copy);
	        count = stack.size();
	        }
		catch(Exception StackOverflowException) {
			
		}
		
	}
	
}
