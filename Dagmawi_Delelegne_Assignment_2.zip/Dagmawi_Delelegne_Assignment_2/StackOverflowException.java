
/**
 * 
 * @author Dagmawi Delelenge
 *
 */
public class StackOverflowException extends Exception {
	/**
	 * Default constructor of StackOverflowException.
	 */
	public StackOverflowException() {
		super("The Stack is full!");
	}
}
