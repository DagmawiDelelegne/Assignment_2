
/**
 * This class contains methods to convert infix expression to postfix expression and viceversa.
 *  It also contains a method that evaluates the expressions.
 * @author Dagmawi Delelegne
 *
 */
public class Notation {
		/**
		 * 
		 * @param infix
		 * @return String infix changed to postfix form.
		 * @throws InvalidNotationFormatException
		 */
	    public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException{
	        StringBuilder postfix = new StringBuilder();
	        MyQueue<Character> operandQueue = new MyQueue<Character>();
	        MyStack<Character> operatorStack = new MyStack<Character>();
	        int temp = 0;
	        
	         char [] c = infix.toCharArray();	
	        
	         try {
	        for(int i = 0; i < c.length; i++) {
	        	
	        		if(Character.isDigit(c[i])) {
	        			operandQueue.enqueue(c[i]);
	        		}
	        		else if(isOperator(c[i])) {
	        			operatorStack.push(c[i]);
	        		}
	        		if(c[i] == ')') {
	        			
	        			while(operatorStack.top() != '(' && !operatorStack.isEmpty()) {
	        			operandQueue.enqueue(operatorStack.pop());
	        			if(operatorStack.isEmpty()) {
	        				throw new InvalidNotationFormatException();
	        			}
	        			}
	        			if(operatorStack.top() == '(') {
	        				operatorStack.pop();
	        			}
	        		}
	        	
	        	}
	        	temp = operandQueue.size();
	        	for(int i = 0; i < temp; i++) {
	        		postfix.append(operandQueue.dequeue());
	        		
	        	} 
	        	
	        	for(int i = 0; i < operatorStack.count; i++) {
	        		postfix.append(operatorStack.pop());
	        	}
	        }
	        	
	        	catch(QueueOverflowException e) {
	        		e.printStackTrace();
	        	}
	        	catch(StackOverflowException e){
	        		e.printStackTrace();
	        	}
	        	catch(StackUnderflowException e) {
	        		e.printStackTrace();
	        	}
	         	catch(QueueUnderflowException e) {
	         		e.printStackTrace();	         	}
	        
	        
	        return postfix.toString();	    }
	    
	    /**
	     * checks if the character entered is 
	     * a character or not.
	     * @param check
	     * @return true or false.
	     */
	    public static boolean isOperator(char check) {
	    	if(check == '+' || check == '-' || check == '/' || check == '*' || check == '(') {
	    		return true;
	    	}
	    	else return false;
	    	
	    }
	    
	    
	    /**
	     * this method changes infix expression to postfix.
	     * @param postfix
	     * @return String infix form of postfix.
	     * @throws InvalidNotationFormatException
	     */
	    public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException {
	    	  MyStack<String> infixStack = new MyStack<String>();
	    	  String temp = "";
	    	  try {
	    	  for(int j = 0; j < postfix.length(); j++) {
	    		  
	    		  if(Character.isDigit(postfix.charAt(j))){
	    			  
	    			  infixStack.push(String.valueOf(postfix.charAt(j)));
	    		  }
	    		  else if(isOperator(postfix.charAt(j))) {
	    			  
	    			  if(infixStack.count < 2) {
	    				  throw new InvalidNotationFormatException();
	    				  }
	    			  else {
	    				  String str1 = infixStack.pop();
	    				  String str2 = infixStack.pop();
	    				  infixStack.push("("+str2+postfix.charAt(j)+str1+")");
	    			  }
	    		  }
	    	  	}
	    	  temp = infixStack.pop();
	    	  }
	    	  
	    	  catch(StackOverflowException e) {
	    		  e.printStackTrace();
	    	  }
	    	  catch(StackUnderflowException e) {
	    		  e.printStackTrace();
	    	  }
	    	  return temp;
	    	  }
	        /**
	         * Evaluates a postfix expression.
	         * @param postfix
	         * @return double result of evaluating the expression.
	         * @throws InvalidNotationFormatException
	         */
	    public static double evaluatePostfixExpression(String postfix) throws InvalidNotationFormatException {
	        MyStack<Double> operandStack = new MyStack<Double>();
	        double temp=0;
	        try {
	        	
	        	for (char c : postfix.toCharArray()) {
	                if (Character.isDigit(c)) {
	                    operandStack.push(Double.parseDouble(String.valueOf(c)));
	                } else if (isOperator(c)) {
	                    if (operandStack.size() < 2) {
	                        throw new InvalidNotationFormatException("Invalid postfix expression.");
	                    }
	                    double operand2 = operandStack.pop();
	                    double operand1 = operandStack.pop();
	                    double result = performOperation(operand1, operand2, c);
	                    operandStack.push(result);
	                }
	            }

	        if (operandStack.size() != 1) {
	            throw new InvalidNotationFormatException();
	        }
	        temp = operandStack.pop();
	        }
	        
        	catch(StackOverflowException e){
        		e.printStackTrace();
        	}
        	catch(StackUnderflowException e) {
        		e.printStackTrace();
        	}
	        System.out.println(temp);
	        return temp;
	    }
	    /**
	     * 
	     * @param operand1
	     * @param operand2
	     * @param operator
	     * @return	double the result of an operation.
	     * @throws InvalidNotationFormatException
	     */
	    private static double performOperation(double operand1, double operand2, char operator) throws InvalidNotationFormatException {
	        switch (operator) {
	            case '+':
	                return operand1 + operand2;
	            case '-':
	                return operand1 - operand2;
	            case '*':
	                return operand1 * operand2;
	            case '/':
	                if (operand2 == 0) {
	                    throw new ArithmeticException("Division by zero.");
	                }
	                return operand1 / operand2;
	            default:
	                throw new InvalidNotationFormatException("Invalid operator: " + operator);
	        }
	    }
	    
	    
	}

	


