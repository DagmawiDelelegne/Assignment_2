
/**
 * 
 * @author Dagmawi Delelegne
 *
 */
public class QueueOverflowException extends Exception{
	/**
	 * Default constructor of QueueOverflowException.
	 */
	public QueueOverflowException() {
		super("Queue is full!");
	}
}
