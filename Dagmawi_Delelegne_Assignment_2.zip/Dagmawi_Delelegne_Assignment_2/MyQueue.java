package Assignment_2;

import java.util.ArrayList;
/**
 * 
 * @author Dagmawi Delelegne
 *
 * @param <T>
 */
public class MyQueue<T> implements QueueInterface <T> {
	private int sizeQueue, count,front,back =0;
	private ArrayList <T> queue;
	/**
	 * Empty constructor that initalizes the variable sizeQueue and queue.
	 * 
	 */
	public MyQueue(){
		sizeQueue = 100;
		queue = new ArrayList<T>(sizeQueue);
	}
	/**
	 * A constructor that takes in sizeQueue and initializes the variable sizeQueue and uses it as a size for 
	 * queue. queue is also initialized.
	 * @param sizeQueue
	 */
	public MyQueue(int sizeQueue){
		this.sizeQueue = sizeQueue;
		this.queue = new ArrayList <T>(sizeQueue);
	}
	
	/**
	 * returns true or false based on the fact that the arrayList is empty or not.
	 * @return boolean
	 */
	@Override
	public boolean isEmpty() {
		
		if (count == 0) {
			return true;
		}
		else {
			return false;
		}
		
	}
	/**
	 * returns true or false based on the fact that the arrayList is full or not.
	 * @return boolean
	 */
	@Override
	public boolean isFull() {
		if (count == sizeQueue)
			return true;
		else			
			return false; 
	}
	/**
	 * returns and removes the element at the front of the queue.
	 * @return T
	 */
	@Override
	public T dequeue() throws QueueUnderflowException {
		
		T item;
		
		if(count == 0)
			throw new QueueUnderflowException();
			
		else { 
			item = queue.get(front);	
			front++;
			count--;
		}
		return item;
	}
	/**
	 * returns the current size
	 * @return count
	 */
	@Override
	public int size() {
		return count;
	}
	/**
	 * returns true if the addition of the element was successful false if not.
	 * @param e
	 * @return boolean
	 */
	@Override
	public boolean enqueue(T e) throws QueueOverflowException {
		
		if(queue.size() == sizeQueue)
			throw new QueueOverflowException();
		else {
			queue.add(e);
			count++;
			return true;
		}
		
	}
	/**
	 * returns a string form of the queue.
	 * @return String
	 */
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		for(int i = front ; i < queue.size(); i++) {
			str.append(queue.get(i));
			
		}
		return str.toString();
	}
	/**
	 * returns a string form of the queue with a delimiter between each element.
	 * @return String
	 */
	@Override
	public String toString(String delimiter) {
		StringBuilder str = new StringBuilder();
		for(int i = front ; i < queue.size(); i++) {
			str.append(queue.get(i)).append(delimiter);
			
		}
		str.deleteCharAt(str.length()-1);
		return str.toString();
	}
	/**
	 * copys and adds the contents of the arrayList to queue.
	 * @param ArrayList<T> list
	 */
	@Override
	public void fill(ArrayList<T> list) {
		
		ArrayList<T> queue2 = new ArrayList<T>(list);
		queue.addAll(queue2);
		count = queue.size();
		
	}

}
