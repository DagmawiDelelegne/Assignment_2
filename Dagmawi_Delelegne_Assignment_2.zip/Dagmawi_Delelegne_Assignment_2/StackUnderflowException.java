
/**
 * 
 * @author Dagmawi Delelenge
 *
 */
public class StackUnderflowException extends Exception {
	/**
	 * Default constructor of StackUnderflowException.
	 */
	public StackUnderflowException() {
		super("The stack is empty!");
	}
}
